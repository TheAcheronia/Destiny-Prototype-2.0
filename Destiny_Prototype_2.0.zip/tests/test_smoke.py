from pathlib import Path
from destiny.core.config import AppConfig

def test_config_load():
    cfg = AppConfig.load(Path(__file__).parents[1] / "config.yaml")
    assert cfg.app.name == "Destiny"
