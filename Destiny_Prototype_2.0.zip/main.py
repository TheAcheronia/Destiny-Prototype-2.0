import asyncio
import os
import sys
from pathlib import Path

from destiny.core.config import AppConfig
from destiny.core.bus import EventBus
from destiny.core.router import Router
from destiny.gui.kivy_app import run_gui

def main():
    cfg = AppConfig.load(Path(__file__).parent / "config.yaml")
    bus = EventBus()
    router = Router(cfg, bus)

    # Start GUI (which starts the async runtime)
    run_gui(cfg, bus, router)

if __name__ == "__main__":
    main()
