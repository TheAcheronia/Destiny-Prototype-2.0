import asyncio
from typing import Callable, Dict, Any, List

class EventBus:
    """A very small pub/sub bus for UI↔core events."""
    def __init__(self):
        self._subs: Dict[str, List[Callable[[Any], None]]] = {}

    def subscribe(self, topic: str, fn: Callable[[Any], None]) -> None:
        self._subs.setdefault(topic, []).append(fn)

    def publish(self, topic: str, payload: Any) -> None:
        for fn in self._subs.get(topic, []):
            fn(payload)
