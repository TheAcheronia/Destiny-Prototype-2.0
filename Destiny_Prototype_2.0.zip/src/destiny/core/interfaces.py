from __future__ import annotations
from typing import Protocol, runtime_checkable, Any

@runtime_checkable
class LLMEngine(Protocol):
    async def complete(self, prompt: str, tools: list[dict] | None = None) -> dict: ...

@runtime_checkable
class STTEngine(Protocol):
    async def listen_once(self) -> str: ...

@runtime_checkable
class TTSEngine(Protocol):
    async def speak(self, text: str, interrupt_flag) -> None: ...
    def stop(self) -> None: ...

@runtime_checkable
class WakeEngine(Protocol):
    async def wait_wake(self) -> None: ...
