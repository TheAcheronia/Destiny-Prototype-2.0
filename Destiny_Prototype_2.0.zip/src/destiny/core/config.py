from __future__ import annotations
from pathlib import Path
from pydantic import BaseModel
import yaml
import os

class LLMOpenAI(BaseModel):
    model: str = "gpt-4o-mini"
    api_key: str | None = None

class LLMGemini(BaseModel):
    model: str = "gemini-1.5-flash"
    api_key: str | None = None

class LLMLlamaCpp(BaseModel):
    model_path: str
    n_ctx: int = 4096

class LLMConfig(BaseModel):
    engine: str = "simple"
    temperature: float = 0.7
    max_tokens: int = 256
    openai: LLMOpenAI = LLMOpenAI()
    gemini: LLMGemini = LLMGemini()
    llama_cpp: LLMLlamaCpp = LLMLlamaCpp(model_path="./models/llama.gguf")

class STTVosk(BaseModel):
    model_path: str

class STTWhisperAPI(BaseModel):
    provider: str = "openai"
    api_key: str | None = None

class STTConfig(BaseModel):
    engine: str = "mock"
    vosk: STTVosk = STTVosk(model_path="./models/vosk")
    whisper_api: STTWhisperAPI = STTWhisperAPI()

class TTSPyttsx3(BaseModel):
    rate: int = 175
    volume: float = 1.0
    voice: str | None = None

class TTSCoqui(BaseModel):
    model: str = "tts_models/en/ljspeech/tacotron2-DDC"
    speaker: str | None = None

class TTSConfig(BaseModel):
    engine: str = "pyttsx3"
    pyttsx3: TTSPyttsx3 = TTSPyttsx3()
    coqui: TTSCoqui = TTSCoqui()

class WakeOpenWakeWord(BaseModel):
    model_path: str = "./models/oww_v0_2.tflite"

class WakeConfig(BaseModel):
    engine: str = "mock"
    openwakeword: WakeOpenWakeWord = WakeOpenWakeWord()

class AppBlock(BaseModel):
    name: str = "Destiny"
    wake_word: str = "destiny"
    interrupt_key: str = "escape"

class AppConfig(BaseModel):
    app: AppBlock = AppBlock()
    llm: LLMConfig = LLMConfig()
    stt: STTConfig = STTConfig()
    tts: TTSConfig = TTSConfig()
    wakeword: WakeConfig = WakeConfig()

    @staticmethod
    def load(path: Path) -> "AppConfig":
        with open(path, "r", encoding="utf-8") as f:
            raw = yaml.safe_load(f)
        cfg = AppConfig.model_validate(raw)

        # Load env keys if not present
        if not cfg.llm.openai.api_key:
            cfg.llm.openai.api_key = os.getenv("OPENAI_API_KEY")
        if not cfg.llm.gemini.api_key:
            cfg.llm.gemini.api_key = os.getenv("GEMINI_API_KEY")
        if not cfg.stt.whisper_api.api_key:
            cfg.stt.whisper_api.api_key = os.getenv("OPENAI_API_KEY")

        return cfg
