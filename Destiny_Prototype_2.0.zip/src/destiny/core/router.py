from __future__ import annotations
import asyncio
from typing import Optional, Dict, Any
from .config import AppConfig
from .bus import EventBus
from ..modules.llm.simple_engine import SimpleLLM
from ..modules.llm.openai_client import OpenAILLM
from ..modules.llm.gemini_client import GeminiLLM
from ..modules.llm.llama_cpp_client import LlamaCppLLM

from ..modules.stt.mock_engine import MockSTT
from ..modules.stt.vosk_engine import VoskSTT
from ..modules.stt.whisper_api import WhisperAPISTT

from ..modules.tts.pyttsx3_engine import Pyttsx3TTS
from ..modules.tts.coqui_engine import CoquiTTS

from ..modules.wakeword.mock_wake import MockWake
from ..modules.wakeword.openwake_engine import OpenWakeWord

from ..skills.loader import SkillRouter

class Router:
    def __init__(self, cfg: AppConfig, bus: EventBus):
        self.cfg = cfg
        self.bus = bus
        self.skills = SkillRouter(bus)

        # Engines (lazy)
        self._llm = None
        self._stt = None
        self._tts = None
        self._wake = None

    def llm(self):
        if self._llm: return self._llm
        e = self.cfg.llm.engine
        if e == "simple": self._llm = SimpleLLM(self.skills)
        elif e == "openai": self._llm = OpenAILLM(self.cfg.llm)
        elif e == "gemini": self._llm = GeminiLLM(self.cfg.llm)
        elif e == "llama_cpp": self._llm = LlamaCppLLM(self.cfg.llm)
        else: raise ValueError(f"Unknown LLM engine {e}")
        return self._llm

    def stt(self):
        if self._stt: return self._stt
        e = self.cfg.stt.engine
        if e == "mock": self._stt = MockSTT(self.bus)
        elif e == "vosk": self._stt = VoskSTT(self.cfg.stt)
        elif e == "whisper_api": self._stt = WhisperAPISTT(self.cfg.stt)
        else: raise ValueError(f"Unknown STT engine {e}")
        return self._stt

    def tts(self):
        if self._tts: return self._tts
        e = self.cfg.tts.engine
        if e == "pyttsx3": self._tts = Pyttsx3TTS(self.cfg.tts)
        elif e == "coqui": self._tts = CoquiTTS(self.cfg.tts)
        else: raise ValueError(f"Unknown TTS engine {e}")
        return self._tts

    def wake(self):
        if self._wake: return self._wake
        e = self.cfg.wakeword.engine
        if e == "mock": self._wake = MockWake(self.cfg.app.wake_word, self.bus)
        elif e == "openwakeword": self._wake = OpenWakeWord(self.cfg.wakeword)
        else: raise ValueError(f"Unknown wake engine {e}")
        return self._wake
