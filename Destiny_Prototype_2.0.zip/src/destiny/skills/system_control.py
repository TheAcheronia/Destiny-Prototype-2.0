from __future__ import annotations
import platform, re, os, subprocess
from .base import SkillBase

class SystemVolume(SkillBase):
    name = "system_volume"
    description = "Adjust volume up/down/mute (best effort, per OS)."

    async def run(self, **kwargs):
        q = (kwargs.get("query") or "").lower()
        osname = platform.system().lower()
        try:
            if "up" in q or "increase" in q or "+" in q:
                return await self._adjust(osname, "up")
            if "down" in q or "decrease" in q or "-" in q:
                return await self._adjust(osname, "down")
            if "mute" in q:
                return await self._adjust(osname, "mute")
            return "Say 'volume up/down/mute'."
        except Exception as e:
            return f"Volume change failed: {e}"

    async def _adjust(self, osname: str, action: str) -> str:
        if "windows" in osname:
            # Requires nircmd or use PowerShell (best-effort)
            if action == "up":
                subprocess.Popen(["powershell","-Command","(new-object -ComObject WScript.Shell).SendKeys([char]175)"])
            elif action == "down":
                subprocess.Popen(["powershell","-Command","(new-object -ComObject WScript.Shell).SendKeys([char]174)"])
            else:
                subprocess.Popen(["powershell","-Command","(new-object -ComObject WScript.Shell).SendKeys([char]173)"])
            return "Windows volume adjusted."
        if "darwin" in osname or "mac" in osname:
            # macOS: requires osascript
            inc = "set volume output volume ((output volume of (get volume settings)) + 10) --100 max"
            dec = "set volume output volume ((output volume of (get volume settings)) - 10) --0 min"
            mute = "set volume with output muted"
            cmd = inc if action=="up" else dec if action=="down" else mute
            subprocess.Popen(["osascript","-e", cmd])
            return "macOS volume adjusted."
        if "linux" in osname:
            # Linux: use pactl if available
            if action == "up":
                subprocess.Popen(["bash","-lc","pactl set-sink-volume @DEFAULT_SINK@ +10%"])
            elif action == "down":
                subprocess.Popen(["bash","-lc","pactl set-sink-volume @DEFAULT_SINK@ -10%"])
            else:
                subprocess.Popen(["bash","-lc","pactl set-sink-mute @DEFAULT_SINK@ toggle"])
            return "Linux volume adjusted."
        return "Unknown OS."

SystemVolumeCls = SystemVolume
