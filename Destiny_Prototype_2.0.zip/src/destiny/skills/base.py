from __future__ import annotations
import asyncio

class SkillBase:
    name = "base"
    description = "Base skill"
    def __init__(self, bus):
        self.bus = bus
    async def run(self, **kwargs):
        raise NotImplementedError
