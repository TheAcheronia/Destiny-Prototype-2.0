from __future__ import annotations
import re, webbrowser
from .base import SkillBase

class OpenURL(SkillBase):
    name = "open_url"
    description = "Open a URL or search the web."

    def _extract(self, text: str) -> str:
        m = re.search(r"(https?://\\S+)", text)
        if m:
            return m.group(1)
        return "https://www.google.com/search?q=" + re.sub(r"\\s+", "+", text.strip())

    async def run(self, **kwargs):
        q = kwargs.get("query", "")
        url = self._extract(q)
        webbrowser.open(url)
        return f"Opened: {url}"

OpenURLCls = OpenURL
