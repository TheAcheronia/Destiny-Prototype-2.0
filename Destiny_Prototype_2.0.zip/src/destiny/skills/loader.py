from __future__ import annotations
import importlib, pkgutil, asyncio, re
from typing import Dict, Callable
from .base import SkillBase

class SkillRouter:
    def __init__(self, bus):
        self.bus = bus
        self.registry: Dict[str, SkillBase] = {}
        self._autodiscover()

    def _autodiscover(self):
        import destiny.skills as skills_pkg
        for mod in pkgutil.iter_modules(skills_pkg.__path__):
            if mod.name.startswith("_"): 
                continue
            module = importlib.import_module(f"destiny.skills.{mod.name}")
            for attr in dir(module):
                val = getattr(module, attr)
                if isinstance(val, type) and issubclass(val, SkillBase) and val is not SkillBase:
                    inst = val(self.bus)
                    self.registry[inst.name] = inst

    async def call(self, name: str, **kwargs):
        sk = self.registry.get(name)
        if not sk:
            return f"Skill '{name}' not found."
        return await sk.run(**kwargs)
