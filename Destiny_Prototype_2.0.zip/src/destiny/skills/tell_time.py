from __future__ import annotations
import datetime as dt
from .base import SkillBase

class TellTime(SkillBase):
    name = "tell_time"
    description = "Returns the local current time."

    async def run(self, **kwargs):
        now = dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        return f"The time is {now}."

TellTimeCls = TellTime
