# Placeholder for future audio I/O/VAD streaming
# Intentionally minimal to keep the base scaffold dependency-light.
