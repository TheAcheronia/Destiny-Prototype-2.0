from __future__ import annotations
import asyncio
import threading
from functools import partial

from kivy.app import App
from kivy.lang import Builder
from kivy.properties import StringProperty, BooleanProperty
from kivy.uix.boxlayout import BoxLayout

KV = """
<Root>:
    orientation: "vertical"
    padding: "16dp"
    spacing: "12dp"

    BoxLayout:
        size_hint_y: None
        height: "44dp"
        Label:
            text: app.title_text
            bold: True
            font_size: "20sp"
    BoxLayout:
        size_hint_y: None
        height: "36dp"
        Label:
            id: status
            text: root.status
    ScrollView:
        GridLayout:
            id: convo
            cols: 1
            size_hint_y: None
            height: self.minimum_height
            padding: "8dp"
            spacing: "8dp"

    BoxLayout:
        size_hint_y: None
        height: "44dp"
        Button:
            text: "🎙️ Wake (mock)"
            on_release: root.on_wake()
        Button:
            text: "⏹ Stop TTS"
            on_release: root.on_stop_tts()
"""

class Root(BoxLayout):
    status = StringProperty("Idle")
    listening = BooleanProperty(False)

    def __init__(self, cfg, bus, router, **kwargs):
        super().__init__(**kwargs)
        self.cfg = cfg
        self.bus = bus
        self.router = router
        self.interrupt_flag = asyncio.Event()

        self.bus.subscribe("convo:add", self._add_convo)
        self.bus.subscribe("status", self._set_status)

    def _add_convo(self, payload):
        role, text = payload.get("role"), payload.get("text")
        from kivy.uix.label import Label
        lab = Label(text=f"[b]{role}[/b]: {text}", markup=True, size_hint_y=None)
        lab.bind(texture_size=lambda inst, val: setattr(inst, "height", val[1]))
        self.ids.convo.add_widget(lab)

    def _set_status(self, text):
        self.status = text

    def on_wake(self):
        # Simulate wake -> stt -> llm -> tts chain
        asyncio.get_event_loop().create_task(self.pipeline())

    async def pipeline(self):
        self.bus.publish("status", "Wake word detected (mock). Listening...")
        self.interrupt_flag.clear()
        # STT
        text = await self.router.stt().listen_once()
        if not text:
            self.bus.publish("status", "Heard nothing.")
            return
        self.bus.publish("convo:add", {"role": "User", "text": text})
        self.bus.publish("status", "Thinking...")
        # LLM
        reply = await self.router.llm().complete(text)
        out = reply.get("text", "")
        tools = reply.get("tools", [])
        if tools:
            res = await self.router.llm().handle_tools(tools)
            out += f"\\n\\n{res}"
        self.bus.publish("convo:add", {"role": "Assistant", "text": out})
        # TTS
        self.bus.publish("status", "Speaking... (interruptible)")
        await self.router.tts().speak(out, self.interrupt_flag)
        self.bus.publish("status", "Idle")

    def on_stop_tts(self):
        self.interrupt_flag.set()
        self.router.tts().stop()
        self.bus.publish("status", "Stopped.")

class DestinyApp(App):
    title_text = "Destiny"

    def __init__(self, cfg, bus, router, **kwargs):
        super().__init__(**kwargs)
        self.cfg, self.bus, self.router = cfg, bus, router
        self.title_text = cfg.app.name

    def build(self):
        Builder.load_string(KV)
        return Root(self.cfg, self.bus, self.router)

def run_gui(cfg, bus, router):
    # Kivy owns the main thread; we attach asyncio loop
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    app = DestinyApp(cfg, bus, router)
    threading.Thread(target=loop.run_forever, daemon=True).start()
    app.run()
    loop.stop()
