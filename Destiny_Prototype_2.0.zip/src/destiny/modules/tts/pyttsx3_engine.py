from __future__ import annotations
import asyncio
import pyttsx3

class Pyttsx3TTS:
    def __init__(self, cfg):
        self.cfg = cfg
        self.engine = pyttsx3.init()
        p = cfg.pyttsx3
        self.engine.setProperty("rate", p.rate)
        self.engine.setProperty("volume", p.volume)
        if p.voice:
            self.engine.setProperty("voice", p.voice)

    async def speak(self, text: str, interrupt_flag) -> None:
        loop = asyncio.get_event_loop()
        def _run():
            self.engine.say(text)
            self.engine.runAndWait()
        await loop.run_in_executor(None, _run)

    def stop(self) -> None:
        try:
            self.engine.stop()
        except Exception:
            pass
