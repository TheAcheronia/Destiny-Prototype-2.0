from __future__ import annotations
import asyncio
class CoquiTTS:
    def __init__(self, cfg):
        self.cfg = cfg
        # from TTS.api import TTS  # heavy dep; lazy import later
        self._tts = None

    async def speak(self, text: str, interrupt_flag) -> None:
        # implement when coqui is installed
        return

    def stop(self) -> None:
        return
