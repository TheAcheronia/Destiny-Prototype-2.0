from __future__ import annotations
import asyncio
class OpenWakeWord:
    def __init__(self, cfg):
        self.cfg = cfg
        try:
            import openwakeword  # noqa
        except Exception:
            raise RuntimeError("openwakeword not installed. pip install openwakeword")

    async def wait_wake(self) -> None:
        # Implement live audio stream feed to OWW model
        return
