from __future__ import annotations
import asyncio
from ...core.bus import EventBus

class MockWake:
    def __init__(self, keyword: str, bus: EventBus):
        self.keyword = keyword
        self.bus = bus

    async def wait_wake(self) -> None:
        # GUI uses a button; this is kept for future background loop
        self.bus.publish("status", f"Say '{self.keyword}' (mock)…")
        await asyncio.sleep(0.1)
