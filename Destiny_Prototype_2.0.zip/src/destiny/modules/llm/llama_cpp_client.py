from __future__ import annotations
import asyncio, os
class LlamaCppLLM:
    def __init__(self, cfg):
        self.cfg = cfg
        # Lazy import to avoid hard dep
        try:
            from llama_cpp import Llama
        except Exception:
            raise RuntimeError("llama-cpp-python not installed.")
        self.llm = Llama(model_path=cfg.llama_cpp.model_path, n_ctx=cfg.llama_cpp.n_ctx)

    async def complete(self, prompt: str, tools=None) -> dict:
        from concurrent.futures import ThreadPoolExecutor
        def _call():
            out = self.llm(prompt, max_tokens=self.cfg.max_tokens, temperature=self.cfg.temperature)
            return out["choices"][0]["text"]
        loop = asyncio.get_event_loop()
        text = await loop.run_in_executor(None, _call)
        return {"text": text}
