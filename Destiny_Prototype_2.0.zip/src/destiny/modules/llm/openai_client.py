from __future__ import annotations
import os, asyncio
from typing import Any, Dict
try:
    from openai import OpenAI
except Exception:
    OpenAI = None

class OpenAILLM:
    def __init__(self, cfg):
        self.cfg = cfg
        if OpenAI is None:
            raise RuntimeError("openai package not installed. pip install openai")
        key = cfg.openai.api_key
        if not key:
            raise RuntimeError("OPENAI_API_KEY not set")
        self.client = OpenAI(api_key=key)

    async def complete(self, prompt: str, tools=None) -> dict:
        from concurrent.futures import ThreadPoolExecutor
        def _call():
            msg = [{"role": "user", "content": prompt}]
            resp = self.client.chat.completions.create(
                model=self.cfg.openai.model,
                messages=msg,
                temperature=self.cfg.temperature,
                max_tokens=self.cfg.max_tokens,
            )
            return resp.choices[0].message.content
        loop = asyncio.get_event_loop()
        text = await loop.run_in_executor(None, _call)
        return {"text": text}
