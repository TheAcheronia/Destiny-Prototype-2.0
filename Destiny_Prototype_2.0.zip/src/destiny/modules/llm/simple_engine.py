from __future__ import annotations
import asyncio
from typing import Any, Dict

class SimpleLLM:
    """Rules & skill router backed 'LLM' – works offline.
    - Calls skills by simple intent keywords.
    - Otherwise echoes a friendly answer.
    """
    def __init__(self, skills):
        self.skills = skills

    async def complete(self, prompt: str, tools: list[dict] | None = None) -> dict:
        text = prompt.strip().lower()

        # naive intent routing
        if "time" in text:
            return {"text": "Let me check the time…", "tools": [{"name": "tell_time", "args": {}}]}
        if text.startswith("open ") or "open url" in text:
            return {"text": "Opening as requested…", "tools": [{"name": "open_url", "args": {"query": prompt}}]}
        if "volume" in text:
            return {"text": "Adjusting volume…", "tools": [{"name": "system_volume", "args": {"query": prompt}}]}

        # default friendly response
        return {"text": "I heard: " + prompt}

    async def handle_tools(self, tools: list[dict]) -> str:
        outs = []
        for t in tools:
            name = t.get("name")
            args = t.get("args", {})
            res = await self.skills.call(name, **args)
            outs.append(f"[{name}] {res}")
        return "\\n".join(outs)
