from __future__ import annotations
import os, asyncio
try:
    import google.generativeai as genai
except Exception:
    genai = None

class GeminiLLM:
    def __init__(self, cfg):
        self.cfg = cfg
        if genai is None:
            raise RuntimeError("google-generativeai not installed.")
        key = cfg.gemini.api_key
        if not key:
            raise RuntimeError("GEMINI_API_KEY not set")
        genai.configure(api_key=key)
        self.model = genai.GenerativeModel(cfg.gemini.model)

    async def complete(self, prompt: str, tools=None) -> dict:
        from concurrent.futures import ThreadPoolExecutor
        def _call():
            resp = self.model.generate_content(prompt)
            return resp.text
        loop = asyncio.get_event_loop()
        text = await loop.run_in_executor(None, _call)
        return {"text": text}
