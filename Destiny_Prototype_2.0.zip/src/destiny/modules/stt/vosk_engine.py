from __future__ import annotations
import asyncio, os

class VoskSTT:
    def __init__(self, cfg):
        self.cfg = cfg
        try:
            import vosk  # noqa
        except Exception:
            raise RuntimeError("vosk not installed. pip install vosk")
        # Implement mic capture + recognizer here in future.

    async def listen_once(self) -> str:
        # Placeholder to keep import testable
        return ""
