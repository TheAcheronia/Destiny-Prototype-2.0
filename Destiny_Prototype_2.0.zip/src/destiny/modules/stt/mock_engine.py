from __future__ import annotations
import asyncio
from ...core.bus import EventBus

class MockSTT:
    """Prompts the user to type text in a Kivy modal-less way: we publish a status and read from stdin asynchronously.
    Keeps the scaffold runnable everywhere without audio deps.
    """
    def __init__(self, bus: EventBus):
        self.bus = bus

    async def listen_once(self) -> str:
        # In GUI we can't block stdin. Simulate a small async input using a popup in status bar:
        # For simplicity in this scaffold, we use a non-blocking prompt in console when run outside GUI.
        self.bus.publish("status", "Type your request in the console and press Enter…")
        loop = asyncio.get_event_loop()
        text = await loop.run_in_executor(None, input, "> ")
        return text.strip()
