from __future__ import annotations
import asyncio, os

class WhisperAPISTT:
    def __init__(self, cfg):
        self.cfg = cfg
        # Implement remote whisper or local server call

    async def listen_once(self) -> str:
        return ""
